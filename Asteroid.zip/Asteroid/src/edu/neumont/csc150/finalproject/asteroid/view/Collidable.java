package edu.neumont.csc150.finalproject.asteroid.view;

import java.awt.*;

public interface Collidable {
	Rectangle getBounds();
}
