package edu.neumont.csc150.finalproject.asteroid.view;

import java.io.IOException;

/**
 * Created by Patricki on 3/3/2017.
 */
public class GameController {

	static Game AsteroidDefender;

	public static void NewGame() throws IOException, InterruptedException {
		MainMenu menu = new MainMenu();
	}

}
