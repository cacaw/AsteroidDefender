package edu.neumont.csc150.finalproject.asteroid.view;

import java.io.IOException;

/**
 * Created by Patricki on 3/3/2017.
 */
public class AsteroidDefender {

	public static void main(String[] args) throws IOException, InterruptedException {
		GameController.NewGame();
	}

}
