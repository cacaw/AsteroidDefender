package Model;

import java.awt.*;

public interface Collidable {
	public Rectangle getBounds();
}
