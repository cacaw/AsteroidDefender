package Control;

import java.awt.Color;
import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Model.Asteroid;
import Model.Player;

@SuppressWarnings("serial")
public class GameTest extends JPanel {
	private static ArrayList<Asteroid> field= new ArrayList<Asteroid>();
	private Player myThing = new Player();
	private int a=0;
	public GameTest(JFrame frame)
	{
		this.setSize(frame.getWidth(),frame.getHeight());
		field.add(new Asteroid(80,500,690, 15, 17, field, this, myThing));
		field.add(new Asteroid(120,500,90, 15, 17, field, this,myThing));
		field.add(new Asteroid(100,190,690, 15, 17, field, this,myThing));
		field.add(new Asteroid(50,500,500, 15, 17, field, this,myThing));
		field.add(new Asteroid(60,250,90, 15, 17, field, this,myThing));
		field.add(new Asteroid(80,90,90, 15, 17, field, this, myThing));
		field.add(new Asteroid(120,370,90, 15, 17, field, this,myThing));
		field.add(new Asteroid(100,800,690, 15, 17, field, this,myThing));
		field.add(new Asteroid(50,500,900, 15, 17, field, this,myThing));
		field.add(new Asteroid(60,750,490, 15, 17, field, this,myThing));
		this.setBackground(Color.BLACK);
		Player mine = new Player();
	}


	public void move() throws InterruptedException {

		for(Asteroid rock: field)
		{
			rock.move();
			this.repaint();
		}
	}
	
	public void paint(Graphics g)
	{
		super.paint(g);
		for(Asteroid rock: field)
		{
			try {
				rock.paint(g);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		a++;
		if(a==250)
		{
			if(field.size()>0)
			{
				//field.remove(field.get(0));
				a=0;
			}
			
		}
	}
}
