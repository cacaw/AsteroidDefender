package Control;

public class Runner {
	
	public static void main(String[] args) throws InterruptedException {
		GameManage mine= new GameManage();
		mine.run();
		
		
	}
	

}
