package Control;


import javax.swing.JFrame;

public class GameManage {
	
	private GameTest game;
	
	public GameManage()
	{
		JFrame frame = new JFrame("Test");
		
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setLocationRelativeTo(null);
		game = new GameTest(frame);
		frame.add(game);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	/**
	 * loops the game continuously until the frame is closed
	 * @throws InterruptedException
	 */
	public void run() throws InterruptedException
	{
		while (true) {
			Thread.sleep(20);
			game.move();
			//game.repaint();
			
		}
	}
}